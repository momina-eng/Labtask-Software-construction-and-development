import java.util.Scanner;

/**
 * Application entry point and menu controller.
 * Connects ConsoleUI and Inventory but does not own business rules.
 */
public class Project {

    private final Inventory inventory;
    private final ConsoleUI consoleUI;

    public Project(Inventory inventory, ConsoleUI consoleUI) {
        this.inventory = inventory;
        this.consoleUI = consoleUI;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ConsoleUI consoleUI = new ConsoleUI(scanner);
        Inventory inventory = new Inventory();

        loadSampleItems(inventory);

        Project application = new Project(inventory, consoleUI);
        application.run();

        scanner.close();
    }

    public void run() {
        boolean isRunning = true;

        while (isRunning) {
            consoleUI.displayMenu();
            int menuChoice = consoleUI.readMenuChoice();

            switch (menuChoice) {
                case AppConfig.OPTION_ADD_ITEM:
                    addNewItem();
                    break;
                case AppConfig.OPTION_UPDATE_STOCK:
                    updateStock();
                    break;
                case AppConfig.OPTION_VIEW_INVENTORY:
                    viewInventory();
                    break;
                case AppConfig.OPTION_SEARCH_ITEM:
                    searchItem();
                    break;
                case AppConfig.OPTION_EXIT:
                    isRunning = false;
                    break;
                default:
                    consoleUI.displayMessage(AppConfig.MSG_INVALID_CHOICE);
                    break;
            }
        }
    }

    private static void loadSampleItems(Inventory inventory) {
        for (Item sampleItem : AppConfig.createSampleItems()) {
            inventory.addItem(sampleItem);
        }
    }

    private void addNewItem() {
        Item newItem = consoleUI.promptNewItem();
        Inventory.OperationResult result = inventory.addItem(newItem);

        if (result == Inventory.OperationResult.SUCCESS) {
            consoleUI.displayMessage(AppConfig.MSG_ITEM_ADDED);
        } else {
            consoleUI.displayOperationResult(result);
        }
    }

    private void updateStock() {
        Item selectedItem = findItemForUpdate();
        applyStockChange(selectedItem);
    }

    private Item findItemForUpdate() {
        while (true) {
            int itemId = consoleUI.promptUpdateItemId();
            Item foundItem = inventory.searchItem(itemId);

            if (foundItem != null) {
                return foundItem;
            }

            consoleUI.displayMessage(AppConfig.MSG_ITEM_NOT_FOUND_RETRY);
        }
    }

    private void applyStockChange(Item selectedItem) {
        int stockChoice = consoleUI.promptStockUpdateChoice();
        int itemId = selectedItem.getId();

        if (stockChoice == AppConfig.STOCK_ADD) {
            int amountToAdd = consoleUI.promptAddStockAmount();
            Inventory.OperationResult result = inventory.addStock(itemId, amountToAdd);
            showStockResult(result, AppConfig.MSG_STOCK_ADDED);
            return;
        }

        if (stockChoice == AppConfig.STOCK_REMOVE) {
            int amountToRemove = consoleUI.promptRemoveStockAmount();
            Inventory.OperationResult result =
                    inventory.removeStock(itemId, amountToRemove);
            showStockResult(result, AppConfig.MSG_STOCK_REMOVED);
            return;
        }

        consoleUI.displayMessage(AppConfig.MSG_INVALID_INPUT);
    }

    private void showStockResult(
            Inventory.OperationResult result, String successMessage) {
        if (result == Inventory.OperationResult.SUCCESS) {
            consoleUI.displayMessage(successMessage);
        } else {
            consoleUI.displayOperationResult(result);
        }
    }

    private void viewInventory() {
        consoleUI.displayInventory(inventory.getItems());
    }

    private void searchItem() {
        int itemId = consoleUI.promptSearchItemId();
        Item foundItem = inventory.searchItem(itemId);

        if (foundItem == null) {
            consoleUI.displayMessage(AppConfig.MSG_ITEM_NOT_FOUND);
            return;
        }

        consoleUI.displayItemDetails(foundItem);
    }
}
