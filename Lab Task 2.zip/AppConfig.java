/**
 * Central place for application settings, menu values, messages and sample data.
 * Change common values here instead of searching through multiple classes.
 */
public final class AppConfig {

    private AppConfig() {
        // Utility class – prevent instantiation
    }

    // Menu options
    public static final int OPTION_ADD_ITEM = 1;
    public static final int OPTION_UPDATE_STOCK = 2;
    public static final int OPTION_VIEW_INVENTORY = 3;
    public static final int OPTION_SEARCH_ITEM = 4;
    public static final int OPTION_EXIT = 5;

    // Stock update options
    public static final int STOCK_ADD = 1;
    public static final int STOCK_REMOVE = 2;

    // Shared user messages
    public static final String MSG_INVALID_CHOICE = "Invalid Choice";
    public static final String MSG_INVALID_INPUT = "Invalid input!";
    public static final String MSG_INVALID_INTEGER =
            "Invalid Input. Please Enter an integer value e.g. 000";
    public static final String MSG_ITEM_NOT_FOUND = "Item not found";
    public static final String MSG_ITEM_NOT_FOUND_RETRY =
            "Item not found! Please try again.";
    public static final String MSG_ITEM_ADDED = "Item added successfully.";
    public static final String MSG_DUPLICATE_ID =
            "An item with this ID already exists.";
    public static final String MSG_INVALID_ITEM_DATA =
            "Item was not added. Check that quantity and price are not negative.";
    public static final String MSG_STOCK_ADDED = "Stock added successfully.";
    public static final String MSG_STOCK_REMOVED = "Stock removed successfully.";
    public static final String MSG_INVALID_AMOUNT =
            "Amount must be greater than zero.";
    public static final String MSG_INSUFFICIENT_STOCK =
            "Not enough stock available to remove.";
    public static final String MSG_ITEM_FOUND = "Item found.";
    public static final String MSG_END_OF_INVENTORY = "End of Inventory.";

    /**
     * Returns the default sample items used when the application starts.
     */
    public static Item[] createSampleItems() {
        return new Item[] {
                new Item(1, "Apple", 42, 420.20),
                new Item(2, "Book", 52, 325.65),
                new Item(3, "Ball", 62, 1000.25),
                new Item(4, "shoes", 72, 250.75),
                new Item(5, "pen", 82, 650.87)
        };
    }
}
