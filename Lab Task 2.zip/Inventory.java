import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Stores inventory items and enforces inventory business rules.
 * Contains no console input/output so it can be tested independently.
 */
public class Inventory {

    /**
     * Result of an inventory operation. Used for clear feedback and testing.
     */
    public enum OperationResult {
        SUCCESS,
        ITEM_NOT_FOUND,
        INVALID_AMOUNT,
        INSUFFICIENT_STOCK,
        DUPLICATE_ID,
        INVALID_ITEM_DATA
    }

    private final List<Item> items;

    public Inventory() {
        items = new ArrayList<>();
    }

    public OperationResult addItem(Item item) {
        if (item == null || item.getQuantity() < 0 || item.getPrice() < 0) {
            return OperationResult.INVALID_ITEM_DATA;
        }

        if (searchItem(item.getId()) != null) {
            return OperationResult.DUPLICATE_ID;
        }

        items.add(item);
        return OperationResult.SUCCESS;
    }

    public Item searchItem(int itemId) {
        for (Item currentItem : items) {
            if (currentItem.getId() == itemId) {
                return currentItem;
            }
        }
        return null;
    }

    public OperationResult addStock(int itemId, int amount) {
        if (amount <= 0) {
            return OperationResult.INVALID_AMOUNT;
        }

        Item item = searchItem(itemId);
        if (item == null) {
            return OperationResult.ITEM_NOT_FOUND;
        }

        item.addQuantity(amount);
        return OperationResult.SUCCESS;
    }

    public OperationResult removeStock(int itemId, int amount) {
        if (amount <= 0) {
            return OperationResult.INVALID_AMOUNT;
        }

        Item item = searchItem(itemId);
        if (item == null) {
            return OperationResult.ITEM_NOT_FOUND;
        }

        if (item.getQuantity() < amount) {
            return OperationResult.INSUFFICIENT_STOCK;
        }

        item.removeQuantity(amount);
        return OperationResult.SUCCESS;
    }

    /**
     * Returns a read-only view so callers cannot change the list directly.
     */
    public List<Item> getItems() {
        return Collections.unmodifiableList(items);
    }

    public int getItemCount() {
        return items.size();
    }
}
