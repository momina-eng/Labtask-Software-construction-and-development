import java.util.List;
import java.util.Scanner;

/**
 * Handles all console input and output using one shared Scanner.
 * Input validation for numbers is handled here so callers stay simple.
 */
public class ConsoleUI {

    private static final String TABLE_BORDER =
            "----------------------------------------------------------";

    private final Scanner scanner;

    public ConsoleUI(Scanner scanner) {
        this.scanner = scanner;
    }

    public void displayMenu() {
        System.out.println();
        System.out.println("Main Menu");
        System.out.println(AppConfig.OPTION_ADD_ITEM + ". Add new item");
        System.out.println(AppConfig.OPTION_UPDATE_STOCK + ". Update stock");
        System.out.println(AppConfig.OPTION_VIEW_INVENTORY + ". View Inventory");
        System.out.println(AppConfig.OPTION_SEARCH_ITEM + ". Search for item");
        System.out.println(AppConfig.OPTION_EXIT + ". Exit");
        System.out.print("Enter your choice: ");
    }

    public int readMenuChoice() {
        return readIntValue();
    }

    public Item promptNewItem() {
        System.out.print("Enter the name of new item: ");
        String name = scanner.next();

        int quantity = promptInt("Enter the quantity of new item: ");
        double price = promptDouble("Enter the price for new item: ");
        int itemId = promptInt("Enter the id for new item: ");

        return new Item(itemId, name, quantity, price);
    }

    public int promptUpdateItemId() {
        return promptInt("Enter the ID of the item you want to update: ");
    }

    public int promptSearchItemId() {
        return promptInt("Enter the search id: ");
    }

    public int promptStockUpdateChoice() {
        System.out.println("Enter");
        System.out.println(AppConfig.STOCK_ADD + " to Add Stock");
        System.out.println(AppConfig.STOCK_REMOVE + " to Remove Stock");
        return readIntValue();
    }

    public int promptAddStockAmount() {
        return promptInt("Enter the amount of stock you want to add: ");
    }

    public int promptRemoveStockAmount() {
        return promptInt("Enter the amount of stock you want to Remove: ");
    }

    public void displayInventory(List<Item> items) {
        System.out.printf("%-10s %-20s %-10s %-10s%n",
                "Item ID", "Item Name", "Quantity", "Price");
        System.out.println(TABLE_BORDER);

        for (Item item : items) {
            System.out.printf("%-10d %-20s %-10d $%-10.2f%n",
                    item.getId(),
                    item.getName(),
                    item.getQuantity(),
                    item.getPrice());
        }

        System.out.println(TABLE_BORDER);
        displayMessage(AppConfig.MSG_END_OF_INVENTORY);
    }

    public void displayItemDetails(Item item) {
        displayMessage(AppConfig.MSG_ITEM_FOUND);
        System.out.println("Item Id: " + item.getId()
                + " | Item Name: " + item.getName()
                + " | Quantity: " + item.getQuantity()
                + " | Price: " + item.getPrice());
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void displayOperationResult(Inventory.OperationResult result) {
        switch (result) {
            case SUCCESS:
                break;
            case ITEM_NOT_FOUND:
                displayMessage(AppConfig.MSG_ITEM_NOT_FOUND);
                break;
            case INVALID_AMOUNT:
                displayMessage(AppConfig.MSG_INVALID_AMOUNT);
                break;
            case INSUFFICIENT_STOCK:
                displayMessage(AppConfig.MSG_INSUFFICIENT_STOCK);
                break;
            case DUPLICATE_ID:
                displayMessage(AppConfig.MSG_DUPLICATE_ID);
                break;
            case INVALID_ITEM_DATA:
                displayMessage(AppConfig.MSG_INVALID_ITEM_DATA);
                break;
            default:
                displayMessage(AppConfig.MSG_INVALID_INPUT);
                break;
        }
    }

    /**
     * Reads an integer and keeps asking until the user enters a valid number.
     */
    public int promptInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            }

            discardInvalidToken();
            displayMessage(AppConfig.MSG_INVALID_INTEGER);
        }
    }

    /**
     * Reads a double and keeps asking until the user enters a valid number.
     */
    public double promptDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextDouble()) {
                return scanner.nextDouble();
            }

            discardInvalidToken();
            displayMessage(AppConfig.MSG_INVALID_INTEGER);
        }
    }

    private int readIntValue() {
        while (true) {
            if (scanner.hasNextInt()) {
                return scanner.nextInt();
            }

            discardInvalidToken();
            displayMessage(AppConfig.MSG_INVALID_INTEGER);
            System.out.print("Enter your choice: ");
        }
    }

    private void discardInvalidToken() {
        if (scanner.hasNext()) {
            scanner.next();
        }
    }
}
