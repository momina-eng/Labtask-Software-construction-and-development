# Inventory Management System

Console-based Java inventory application for a Software Engineering lab project.

## Project Structure

| File | Responsibility |
| --- | --- |
| `Item.java` | Stores data for one inventory item |
| `Inventory.java` | Inventory storage and business rules |
| `ConsoleUI.java` | Console input/output and shared `Scanner` |
| `Project.java` | Application entry point and menu flow |
| `AppConfig.java` | Menu options, messages and sample data |
| `InventoryTest.java` | Simple business-logic tests (no JUnit) |

## Design Overview

- **Item** holds only item attributes.
- **Inventory** contains searchable stock operations and validation rules.
- **ConsoleUI** owns the single shared `Scanner` and all user prompts/messages.
- **Project** controls the menu loop and connects UI with inventory operations.
- **AppConfig** keeps changeable values in one place for easier maintenance.

## Features

1. Add a new item
2. Update stock (add or remove)
3. View inventory
4. Search for an item by ID
5. Exit

## Compile and Run

From this folder (`InventorySystem`):

```bash
javac *.java
java Project
```

## Run Business Logic Tests

```bash
javac *.java
java InventoryTest
```

## Important Design Decisions

1. Inventory rules (invalid amount, insufficient stock, duplicate ID) live in `Inventory`, not in the UI.
2. Shared messages and menu numbers live in `AppConfig` so they can be changed in one place.
3. Numeric input is validated in `ConsoleUI` so invalid text does not crash the program.
4. `InventoryTest` checks inventory behavior without console interaction.
