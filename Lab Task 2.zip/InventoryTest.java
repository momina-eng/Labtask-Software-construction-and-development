/**
 * Simple console-based tests for Inventory business logic.
 * No external testing framework is required.
 *
 * Run with: java InventoryTest
 */
public class InventoryTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        testAddItemSuccess();
        testAddItemDuplicateId();
        testAddItemInvalidData();
        testSearchExistingItem();
        testSearchMissingItem();
        testAddStockSuccess();
        testAddStockInvalidAmount();
        testRemoveStockSuccess();
        testRemoveStockInsufficient();
        testRemoveStockInvalidAmount();

        System.out.println();
        System.out.println("Tests passed: " + passed);
        System.out.println("Tests failed: " + failed);

        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void testAddItemSuccess() {
        Inventory inventory = new Inventory();
        Inventory.OperationResult result =
                inventory.addItem(new Item(10, "Laptop", 5, 500.0));
        check("addItem success", result == Inventory.OperationResult.SUCCESS);
        check("item count is 1", inventory.getItemCount() == 1);
    }

    private static void testAddItemDuplicateId() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(10, "Laptop", 5, 500.0));
        Inventory.OperationResult result =
                inventory.addItem(new Item(10, "Tablet", 2, 200.0));
        check("duplicate ID rejected",
                result == Inventory.OperationResult.DUPLICATE_ID);
        check("item count stays 1", inventory.getItemCount() == 1);
    }

    private static void testAddItemInvalidData() {
        Inventory inventory = new Inventory();
        Inventory.OperationResult result =
                inventory.addItem(new Item(11, "Broken", -1, 10.0));
        check("negative quantity rejected",
                result == Inventory.OperationResult.INVALID_ITEM_DATA);
    }

    private static void testSearchExistingItem() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(20, "Mouse", 8, 25.0));
        Item found = inventory.searchItem(20);
        check("search finds existing item", found != null);
        check("search returns correct name",
                found != null && "Mouse".equals(found.getName()));
    }

    private static void testSearchMissingItem() {
        Inventory inventory = new Inventory();
        Item found = inventory.searchItem(999);
        check("search missing item returns null", found == null);
    }

    private static void testAddStockSuccess() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(30, "Keyboard", 10, 40.0));
        Inventory.OperationResult result = inventory.addStock(30, 5);
        check("addStock success", result == Inventory.OperationResult.SUCCESS);
        check("quantity increased",
                inventory.searchItem(30).getQuantity() == 15);
    }

    private static void testAddStockInvalidAmount() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(31, "Cable", 3, 5.0));
        Inventory.OperationResult result = inventory.addStock(31, 0);
        check("addStock rejects zero amount",
                result == Inventory.OperationResult.INVALID_AMOUNT);
    }

    private static void testRemoveStockSuccess() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(40, "Monitor", 12, 150.0));
        Inventory.OperationResult result = inventory.removeStock(40, 4);
        check("removeStock success",
                result == Inventory.OperationResult.SUCCESS);
        check("quantity decreased",
                inventory.searchItem(40).getQuantity() == 8);
    }

    private static void testRemoveStockInsufficient() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(41, "Chair", 2, 80.0));
        Inventory.OperationResult result = inventory.removeStock(41, 5);
        check("removeStock rejects insufficient stock",
                result == Inventory.OperationResult.INSUFFICIENT_STOCK);
        check("quantity unchanged",
                inventory.searchItem(41).getQuantity() == 2);
    }

    private static void testRemoveStockInvalidAmount() {
        Inventory inventory = new Inventory();
        inventory.addItem(new Item(42, "Desk", 6, 120.0));
        Inventory.OperationResult result = inventory.removeStock(42, -3);
        check("removeStock rejects negative amount",
                result == Inventory.OperationResult.INVALID_AMOUNT);
    }

    private static void check(String testName, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("[PASS] " + testName);
        } else {
            failed++;
            System.out.println("[FAIL] " + testName);
        }
    }
}
